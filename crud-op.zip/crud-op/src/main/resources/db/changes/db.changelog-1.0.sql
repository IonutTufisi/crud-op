CREATE TABLE proiecte (
    idProiect LONG PRIMARY KEY AUTO_INCREMENT,
    denumire VARCHAR(50) NOT NULL,
    descriere VARCHAR(50) NOT NULL,
    costLunar INT NOT NULL

);